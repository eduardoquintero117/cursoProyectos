//
//  WelcomeViewController.swift
//  ProyectFirebase
//
//  Created by Eduardo Quintero on 07/03/20.
//  Copyright © 2020 new. All rights reserved.
//

import UIKit
import Firebase


class WelcomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func signOut(_ sender: Any){
            var salida = try! Auth.auth().signOut()
            //dismiss(animated: true, completion: nil)
        navigationController?.popViewController(animated: true)
        }

    

}
