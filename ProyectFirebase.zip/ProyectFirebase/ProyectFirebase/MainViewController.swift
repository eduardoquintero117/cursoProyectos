//
//  MainViewController.swift
//  ProyectFirebase
//
//  Created by Eduardo Quintero on 07/03/20.
//  Copyright © 2020 new. All rights reserved.
//

import UIKit
import Firebase

class MainViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
      //isLogget()
         
    }
    
    func isLogget() {
        Auth.auth().addStateDidChangeListener { (auth, user) in
            if user == nil {
                
                print("usuario no loggeado--------------1")
                return
            }else{
                
                print("usuario loggeado-----------------2")
                self.performSegue(withIdentifier: "welcomeView", sender: self)
                 
            }
        }
    }
  

}
