//
//  DetailPhotoViewController.swift
//  ProyectFirebase
//
//  Created by Eduardo Quintero on 14/03/20.
//  Copyright © 2020 iosLab. All rights reserved.
//

import UIKit
import Firebase
import FirebaseFirestore
import FirebaseStorage
import MobileCoreServices
import FirebaseUI


class DetailPhotoViewController : UIViewController{
     var optimizedImage: Data!
    var imagen: UIImage! = nil
     var userID:String!
    let photoView: UIImageView = {
        let pv = UIImageView(frame: CGRect(x: 8, y: 8, width: 300, height: 300))
        
        return pv
    }()
    
    let saveButtton: UIButton = {
        let b = UIButton(type: .system)
        b.setTitle("Descarga Imagen", for: .normal)
        b.translatesAutoresizingMaskIntoConstraints = false
        b.addTarget(self, action: #selector(savePhoto), for: .touchUpInside)
        return b
       }()
    
    let upButtton: UIButton = {
     let b = UIButton(type: .system)
         b.setTitle("Sube Imagen", for: .normal)
         b.translatesAutoresizingMaskIntoConstraints = false
         b.addTarget(self, action: #selector(subirPhoto), for: .touchUpInside)
         return b
    }()
    
    
    override func viewDidLoad() {
        super .viewDidLoad()
        photoView.image = imagen
        view.addSubview(photoView)
        view.addSubview(saveButtton)
        view.addSubview(upButtton)
        photoView.center = view.center
        
        view.backgroundColor = .cyan
        saveButtton.topAnchor.constraint(equalTo: photoView.bottomAnchor, constant: 10).isActive = true
        saveButtton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        
        upButtton.topAnchor.constraint(equalTo: photoView.bottomAnchor , constant: 40).isActive = true
        upButtton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        
       // getRef = Firestore.firestore()
               
               Auth.auth().addStateDidChangeListener { (auth, user) in
                   if user == nil{
                       print("Usuario no loggeado")
                   } else {
                       self.userID = user?.uid
                       
                   }
               }
        
    }
    @objc func savePhoto(){
        print("save")
        guard let image = photoView.image else {return}
        
        UIImageWriteToSavedPhotosAlbum(image, nil, #selector(newImage(_:didFinichSavingWithError:contextInfo:)), nil)
    }
    
    @objc func newImage(_ image: UIImage, didFinichSavingWithError error: Error? , contextInfo: UnsafeRawPointer){
           
           
           
       }
    
    //------------ FireBase
    @objc func subirPhoto(){
        
        if let imageSelected = photoView.image as? UIImage,
        let optimizedImageData = imageSelected.jpegData(compressionQuality: 0.6){
            self.saveImage(optimizedImageData)
        }
    
    }
    
   
    
    
    func saveImage(_ imageData: Data){
        let activityIndicator = UIActivityIndicatorView.init(style: .large)
        activityIndicator.color = .black
        activityIndicator.center = photoView.center

        activityIndicator.startAnimating()
        photoView.addSubview(activityIndicator)
        view.addSubview(activityIndicator)
        
        let storageReference = Storage.storage().reference()
        print(userID)
        let userImageRef = storageReference.child("/photos4").child(userID)
        let uploadMetadata = StorageMetadata()
        
        uploadMetadata.contentType = "image/jpeg"
        
        userImageRef.putData(imageData, metadata: uploadMetadata) { (storageMetadata, error) in
            activityIndicator.stopAnimating()
            activityIndicator.removeFromSuperview()

            if let error = error{
                print("error: ", error.localizedDescription)
            }else{
                print(storageMetadata?.path)
            }
        }
    }

}
