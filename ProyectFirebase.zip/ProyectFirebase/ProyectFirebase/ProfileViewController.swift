//
//  ProfileViewController.swift
//  ProyectFirebase
//
//  Created by Eduardo Quintero on 13/03/20.
//  Copyright © 2020 new. All rights reserved.
//

import UIKit
import Firebase
import FirebaseFirestore
import FirebaseStorage
import MobileCoreServices
import FirebaseUI

class ProfileViewController: UIViewController , UIImagePickerControllerDelegate, UINavigationControllerDelegate{

    @IBOutlet weak var image: UIImageView!
    
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var lastName: UILabel!
    
    //let getRef =
    
    var userID: String!
    var getReff: Firestore!
    
    var optimizedImage: Data!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Auth.auth().addStateDidChangeListener { (auth, user) in
            if user == nil{
                
                
            }else{
                self.userID = user?.uid
                self.lastName.text = user?.email
                self.getName()
                self.getPhoto()
                
            }
        }
   
       
        
    }
    func getPhoto(){
        
        let storageReference = Storage.storage().reference()
               let placeHolder = UIImage(named: "anon")
               
               let userImageRef = storageReference.child("/photos").child(userID)
               
               userImageRef.downloadURL { (url, error) in
                   if let error = error{
                       print(error.localizedDescription)
                   }else{
                    print("Imagen descargada",url)
                   }
                
               }
        image.sd_setImage(with: userImageRef, placeholderImage: placeHolder)
    }

    
    func getName() {
        print(userID)
        print("-----------------")
        //Firestore.firestore
        let result = Firestore.firestore().collection("users").document(userID)
        result.getDocument { (snapshot, error) in
            var lastname2 = snapshot?.get("lastname") as? String ?? "sin valor"
            var name2 = snapshot?.get("name") as? String ?? "sin valor"
            
            self.name.text = " \(name2) \(lastname2)"
        }
    }
   

    @IBAction func upLoadPhoto(_ sender: UIButton) {
        
        
        let photoImage = UIImagePickerController()
        photoImage.sourceType = UIImagePickerController.SourceType.photoLibrary
        
        photoImage.delegate = self
        present(photoImage, animated: true )
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let imageSelected = info[UIImagePickerController.InfoKey.originalImage] as? UIImage,
            let optimizedImageData = imageSelected.jpegData(compressionQuality: 0.6){
            image.image = imageSelected
            optimizedImage =  optimizedImageData
            self.saveImage(optimizedImageData)
        }
        dismiss(animated: true, completion: nil)
    }
    
    func saveImage(_ imageData: Data) {
        let activityIndicator = UIActivityIndicatorView.init(style: .large)
        activityIndicator.color = .red
        activityIndicator.center = view.center
        activityIndicator.center = image.center
        
        activityIndicator.startAnimating()
        view.addSubview(activityIndicator)
        
        let storageReference = Storage.storage().reference()
        let userImageRef = storageReference.child("/photos").child(userID)
        let uploadMetada = StorageMetadata()
        
        uploadMetada.contentType = "image/jpeg"
        
        userImageRef.putData(imageData, metadata: uploadMetada) { (storageMetaData, error) in
            
            activityIndicator.stopAnimating()
            activityIndicator.removeFromSuperview()
            if let error = error {
                print("error", error.localizedDescription)
                
            }else{
                
                print(storageMetaData?.path)
            }
        }
    }
    
}
