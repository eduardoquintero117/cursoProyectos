//
//  PhotoCollectionViewCell.swift
//  ProyectFirebase
//
//  Created by Eduardo Quintero on 14/03/20.
//  Copyright © 2020 iosLab. All rights reserved.
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {
    var photoView: UIImageView = {
        
        let pv = UIImageView(frame: CGRect(x: 0.0, y: 0.0, width: 100, height: 100))
        return pv
        
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        print("pintando")
        addSubview(photoView)
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
    }
    
}
