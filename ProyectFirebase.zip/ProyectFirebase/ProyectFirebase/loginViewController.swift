//
//  loginViewController.swift
//  ProyectFirebase
//
//  Created by Eduardo Quintero on 07/03/20.
//  Copyright © 2020 new. All rights reserved.
//

import UIKit
import Firebase


class loginViewController: UIViewController {

    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func login(_ sender: UIButton) {
        guard let email = emailTF.text, email !=  "" , let password = password.text,  password != "" else {
                   
                   return
                   
               }
            Auth.auth().signIn(withEmail: email, password: password) { (result, error) in
            if let error = error {
                print(error.localizedDescription)
                return

            }else{
                print("Usuario autentificado")
                let welcomeView = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "WelcomeViewController") as? WelcomeViewController
                
                self.dismiss(animated: true) {
                    self.navigationController?.pushViewController(welcomeView!, animated: true)
                }
                
            }
        }
        
        
    }
    
    
    @IBAction func cancel(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    

}
